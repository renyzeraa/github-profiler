/**
 * Onde sera inserido todo o HTML da página
 * @var {HTMLElement}
 */
export const oRoot = document.querySelector('.estrutura')
